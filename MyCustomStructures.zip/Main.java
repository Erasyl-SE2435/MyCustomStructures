public class Main {
    public static void main(String[] args) {
        System.out.println("Testing MyArrayList:");
        MyArrayList<Integer> arrayList = new MyArrayList<>();
        arrayList.add(10); arrayList.add(20); arrayList.add(30);
        System.out.println(arrayList.get(1)); // 20

        System.out.println("Testing MyLinkedList:");
        MyLinkedList<String> linkedList = new MyLinkedList<>();
        linkedList.add("A"); linkedList.add("B"); linkedList.add("C");
        System.out.println(linkedList.get(2)); // C

        System.out.println("Testing MyStack:");
        MyStack<Integer> stack = new MyStack<>();
        stack.push(1); stack.push(2); stack.push(3);
        System.out.println(stack.pop()); // 3

        System.out.println("Testing MyQueue:");
        MyQueue<String> queue = new MyQueue<>();
        queue.enqueue("X"); queue.enqueue("Y"); queue.enqueue("Z");
        System.out.println(queue.dequeue()); // X

        System.out.println("Testing MyMinHeap:");
        MyMinHeap<Integer> heap = new MyMinHeap<>();
        heap.insert(5); heap.insert(3); heap.insert(4);
        System.out.println(heap.extractMin()); // 3
    }
}