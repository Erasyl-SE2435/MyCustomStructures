# My Custom Java Data Structures

## Includes:
- MyArrayList
- MyLinkedList (Doubly)
- MyStack
- MyQueue
- MyMinHeap

## How to Run
Compile all `.java` files and run `Main.java`.

## Structure
- All physical data structures implement `MyList<E>`
- Logical structures are built using these implementations

## Author
Ерасыл Жомартов Габитович — лучший ученик AITU 😎